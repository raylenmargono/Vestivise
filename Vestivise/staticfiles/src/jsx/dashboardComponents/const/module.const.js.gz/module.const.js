export const ModuleConst = {
	BASIC_RISK : "basicRisk",
	BASIC_RETURN : "basicReturn",
	BASIC_ASSET : "basicAsset",
	BASIC_FEE : "basicFee"
}