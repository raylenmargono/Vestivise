import React from 'react';
import ReactDOM from 'react-dom';
import UpdateDataView from '../updateDataComponents/updateDataView.jsx';

const root = document.getElementById('updateDataApp');


ReactDOM.render(<UpdateDataView/>, root);