import React from 'react';
import ReactDOM from 'react-dom';
import LinkAccountView from '../linkAccountComponents/linkAccountView.jsx';

const root = document.getElementById('linkAccountApp');


ReactDOM.render(<LinkAccountView/>, root);